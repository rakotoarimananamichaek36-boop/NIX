'use strict';
/*
 *  NIX net GO — Voucher Ticket Shop
 *  Zero-dependency Node.js server.  Run it with:  node server.js
 *  Edit your shop (name, PIN, prices, plans) in config.json — no DB needed.
 */
const http   = require('http');
const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');

const PORT          = process.env.PORT || 3000;
const ROOT          = __dirname;
const PUBLIC_DIR    = path.join(ROOT, 'public');
const DATA_DIR      = path.join(ROOT, 'data');
const REQUESTS_FILE = path.join(DATA_DIR, 'requests.json');
const CONFIG_FILE   = path.join(ROOT, 'config.json');

/* ------------------------------ storage ------------------------------ */
function loadConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); }
  catch { return { businessName: 'WiFi Vouchers', adminPin: '2026', currency: 'Ar', plans: [] }; }
}
function loadRequests() {
  try { return JSON.parse(fs.readFileSync(REQUESTS_FILE, 'utf8')); }
  catch { return []; }
}
function saveRequests(list) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(REQUESTS_FILE, JSON.stringify(list, null, 2));
}

/* ------------------------- voucher generator ------------------------- */
const CODE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ'; // 5 letters (skips I / L / O / Q — no confusion)
function makeCode() {
  const b = crypto.randomBytes(5);
  let s = '';
  for (let i = 0; i < 5; i++) s += CODE_CHARS[b[i] % CODE_CHARS.length];
  return s;
}
function makePassword() { // 5 digits
  const b = crypto.randomBytes(5);
  let s = '';
  for (let i = 0; i < 5; i++) s += String(b[i] % 10);
  return s;
}

/* --------------------------- rate limiting --------------------------- */
const hits = new Map(); // ip -> [timestamps]
function rateLimited(ip, limit = 8, windowMs = 5 * 60 * 1000) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter(t => now - t < windowMs);
  if (arr.length >= limit) { hits.set(ip, arr); return true; }
  arr.push(now); hits.set(ip, arr);
  return false;
}

/* ------------------------------ helpers ------------------------------ */
function send(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 1e6) req.destroy(); });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}
function isAdmin(req, cfg) {
  return String(req.headers['x-admin-pin'] || '') === String(cfg.adminPin || '');
}

/* --------------------- owner notifications (Telegram) -----------------
 * Set telegramBotToken + telegramChatId in config.json to receive every
 * new customer request directly in Telegram (see README for setup). */
function escHtml(s) { return String(s ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])); }
async function notifyOwner(cfg, tickets, name, phone) {
  try {
    const token = cfg.telegramBotToken, chatId = cfg.telegramChatId;
    if (!token || !chatId) return; // not configured -> skip silently
    const total = tickets.reduce((s, t) => s + (Number(t.price) || 0), 0);
    const lines = [
      `🎟 <b>NEW REQUEST — ${escHtml(cfg.businessName || 'Shop')}</b>`,
      `👤 ${escHtml(name)} — ${escHtml(phone)}`,
      `📦 ${escHtml(tickets[0].planName)}${tickets.length > 1 ? ' × ' + tickets.length : ''} — <b>${total.toLocaleString('fr-FR')} ${escHtml(cfg.currency || '')}</b>`,
      `🕒 ${new Date().toLocaleString('fr-FR')}`,
      '',
      ...tickets.map((t, i) => `${tickets.length > 1 ? `#${i + 1} ` : ''}🔑 <code>${t.code}</code> / <code>${t.password}</code> — ${t.id}`),
    ];
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: lines.join('\n'), parse_mode: 'HTML' }),
    });
  } catch (e) {
    console.error('Telegram notification failed:', e.message);
  }
}

/* ---------------------------- static files --------------------------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.json': 'application/json', '.ico': 'image/x-icon' };
function serveStatic(req, res, pathname) {
  const target = pathname === '/' ? '/index.html' : pathname;
  const file = path.normalize(path.join(PUBLIC_DIR, target));
  if (!file.startsWith(PUBLIC_DIR)) { res.writeHead(404); return res.end('Not found'); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' });
    res.end(buf);
  });
}

/* ------------------------------- server ------------------------------ */
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;
  try {
    const cfg = loadConfig();

    if (req.method === 'GET' && p === '/api/health') return send(res, 200, { ok: true });

    /* Public shop info (adminPin is NEVER sent here) */
    if (req.method === 'GET' && p === '/api/shop') {
      return send(res, 200, {
        businessName: cfg.businessName || 'WiFi Vouchers',
        currency:     cfg.currency || 'Ar',
        paymentInfo:  cfg.paymentInfo || '',
        ownerWhatsApp: cfg.ownerWhatsApp || '',
        plans: Array.isArray(cfg.plans) ? cfg.plans : [],
      });
    }

    /* Customer: create a voucher request -> generate 5-letter code + 5-digit password */
    if (req.method === 'POST' && p === '/api/requests') {
      const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
      if (rateLimited(ip)) return send(res, 429, { error: 'Too many requests. Please wait a few minutes and try again.' });

      let body = {};
      try { body = JSON.parse(await readBody(req) || '{}'); } catch { return send(res, 400, { error: 'Invalid request.' }); }

      const name   = String(body.name || '').trim();
      const phone  = String(body.phone || '').trim();
      const planId = String(body.planId || '');
      const qty    = Math.min(Math.max(parseInt(body.quantity, 10) || 1, 1), 10); // 1..10 vouchers per request

      if (name.length < 2 || name.length > 60)      return send(res, 400, { error: 'Please enter your full name.' });
      if (!/^[0-9+()\s.-]{5,20}$/.test(phone))       return send(res, 400, { error: 'Please enter a valid phone number.' });
      const plan = (cfg.plans || []).find(pl => String(pl.id) === planId);
      if (!plan) return send(res, 400, { error: 'This pass is not available.' });

      const requests = loadRequests();
      const open = requests.filter(r => r.phone === phone && r.status === 'pending').length;
      if (open + qty > 10) return send(res, 409, { error: 'Too many unpaid vouchers on this phone number (maximum 10). Please pay first, then order again.' });

      const tickets = [];
      for (let i = 0; i < qty; i++) {
        const taken = new Set([...requests.map(r => r.code), ...tickets.map(t => t.code)]);
        let code = makeCode(), guard = 0;
        while (taken.has(code) && guard++ < 20) code = makeCode();
        tickets.push({
          id: 'RV-' + crypto.randomBytes(4).toString('hex').toUpperCase(),
          createdAt: new Date().toISOString(),
          name, phone,
          planId: String(plan.id),
          planName: plan.name,
          price: Number(plan.price) || 0,
          code,
          password: makePassword(),
          status: 'pending', // pending -> paid (you confirm the mobile money payment)
        });
      }
      requests.unshift(...tickets);
      saveRequests(requests);
      notifyOwner(cfg, tickets, name, phone).catch(() => {}); // fire & forget
      return send(res, 201, qty === 1 ? tickets[0] : { tickets });
    }

    /* Admin: list ALL requests (private area) */
    if (req.method === 'GET' && p === '/api/requests') {
      if (!isAdmin(req, cfg)) return send(res, 401, { error: 'Unauthorized' });
      return send(res, 200, loadRequests());
    }

    /* Admin: change the dashboard PIN (current PIN required) */
    if (req.method === 'POST' && p === '/api/admin/pin') {
      let body = {};
      try { body = JSON.parse(await readBody(req) || '{}'); } catch { return send(res, 400, { error: 'Invalid request' }); }
      if (String(body.currentPin || '') !== String(cfg.adminPin || '')) return send(res, 401, { error: 'Current PIN is wrong.' });
      const newPin = String(body.newPin || '');
      if (newPin.length < 4 || newPin.length > 32) return send(res, 400, { error: 'New PIN must be 4–32 characters.' });
      cfg.adminPin = newPin;
      try { fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2)); } catch { return send(res, 500, { error: 'Could not save the new PIN.' }); }
      return send(res, 200, { ok: true });
    }

    /* Admin: mark paid / delete one request */
    const m = p.match(/^\/api\/requests\/([^/]+)$/);
    if (m && (req.method === 'PATCH' || req.method === 'DELETE')) {
      if (!isAdmin(req, cfg)) return send(res, 401, { error: 'Unauthorized' });
      const id = decodeURIComponent(m[1]);
      const requests = loadRequests();
      const idx = requests.findIndex(r => r.id === id);
      if (idx === -1) return send(res, 404, { error: 'Not found' });

      if (req.method === 'DELETE') {
        requests.splice(idx, 1);
        saveRequests(requests);
        return send(res, 200, { ok: true });
      }
      let body = {};
      try { body = JSON.parse(await readBody(req) || '{}'); } catch { return send(res, 400, { error: 'Invalid request' }); }
      if (!['pending', 'paid'].includes(body.status)) return send(res, 400, { error: 'Invalid status' });
      requests[idx].status = body.status;
      requests[idx].updatedAt = new Date().toISOString();
      saveRequests(requests);
      return send(res, 200, requests[idx]);
    }

    /* Frontend */
    if (req.method === 'GET' || req.method === 'HEAD') return serveStatic(req, res, p);
    return send(res, 404, { error: 'Not found' });

  } catch (err) {
    console.error(err);
    return send(res, 500, { error: 'Server error' });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('\n  ✅ WiFi voucher shop is running');
  console.log(`  ➜ Local:  http://localhost:${PORT}`);
  console.log('  ➜ Owner:  open the "Owner" tab (PIN lives in config.json)');
});
