# 🌐 Put NIX net GO online — permanent website (FREE)

Follow these steps once. After that your shop has its own address forever,
e.g. `https://nix-net-go.onrender.com` — share it with all your clients.

---

## Step 1 — Create a free account

Go to **https://render.com** → **Get Started** → sign up with email
(free, no credit card needed).

## Step 2 — Put the code on GitHub

1. Go to **https://github.com** → create a free account if you don't have one.
2. Click the **+** (top right) → **New repository** → name it `nix-net-go`
   → **Public** → **Create repository**.
3. On the repo page, click **uploading an existing file**.
4. Drag & drop **ALL the files** from this project folder
   (`server.js`, `package.json`, `config.json`, `public/index.html`,
   `README.md`… easiest is to unzip `nixnetgo.zip` first).
5. Click **Commit changes**.

## Step 3 — Deploy on Render

1. In Render, click **New +** → **Web Service**.
2. Choose **Build and deploy from a Git repository** → connect your GitHub.
3. Select the `nix-net-go` repository.
4. Settings:
   - **Name:** `nix-net-go` (this becomes your URL)
   - **Build command:** leave empty or `npm install`
   - **Start command:** `node server.js`
   - **Instance type:** **Free**
5. Click **Create Web Service** and wait ~2 minutes.

## Step 4 — Use it 🎉

- Your website: `https://<name-you-chose>.onrender.com` — send this link to clients!
- Owner dashboard: open the link → **Owner** tab → your PIN
  (default `2026` — **change it** in Owner → ⚙️ Settings once inside).
- Edit plans/prices later: change `config.json` in your GitHub repo →
  Render auto-redeploys.

💡 Render free tier sleeps after 15 min without visitors and wakes back up
in ~30 seconds when someone opens the link — perfect and free for a voucher shop.
If you want it always instant, the paid tier is ~$7/month.

**No server to buy, nothing to install on your computer — done!**
