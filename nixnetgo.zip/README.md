# 🎟 NIX net GO — Voucher Ticket Shop

A complete web app to sell WiFi voucher tickets:

- **Customers** choose a pass, enter their name + phone, pick **how many vouchers** (1–10), and instantly receive a **Code (5 letters)** + **Password (5 numbers)** *per ticket* — all tickets can be copied or downloaded as images.
- **You (the owner)** open a **private, PIN-protected dashboard** to see *every* customer request: name, phone, plan, price, code, password, date — with search, filters, "mark as paid", delete, revenue stats, a **"Today" summary + last-7-days history**, and a **Settings panel to change your PIN anytime** (Owner tab → ⚙️ Settings at the bottom).
- Data is saved on the server (`data/requests.json`), so you can check requests from **any device**, not just your phone.

## ▶️ Run it

```bash
node server.js
```

Open **http://localhost:3000** → shop for customers, **Owner** tab for you (default PIN: `2026`).

## 🔔 Notifications for new requests (2 ways)

**1. Dashboard alerts (no setup):** alerts are **ON by default** — just unlock the Owner tab once with your PIN and allow notifications. From then on, as long as the app stays open **in any tab view on your computer** (Shop or Owner), you'll get **sound + vibration + a message banner + push notification + flashing title** the moment a customer sends a demand. Your PIN is remembered on your own computer — press **🔒 Lock** to sign out on a shared device.

**2. Telegram alerts (works 24/7 even when the page is closed):**
1. In Telegram, open **@BotFather** → send `/newbot` → pick a name → copy the **token**
2. Send any message (e.g. "hi") to your new bot
3. Open `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates` in your browser → copy the number after `"chat":{"id":`
4. Paste both into `config.json`: `telegramBotToken` and `telegramChatId`

Every new order then arrives in your Telegram with the customer's name, phone, plan, price **and all generated codes** — you can simply reply/forward to confirm.

## ⚙️ Customize (config.json)

| Field | What it does |
|---|---|
| `businessName` | Your shop name, shown everywhere (also on downloaded tickets) |
| `adminPin` | **Your private PIN — change it!** |
| `currency` | `Ar` (Ariary) or anything else |
| `paymentInfo` | Payment instructions shown on the shop page (MVola / Orange Money / Airtel Money number) |
| `plans` | Your passes: id, name, price, details, optional `badge` |

Changes take effect immediately — just refresh the page.

## 💼 How it works (sales flow)

1. Customer picks a pass → request is created → code + password are generated instantly.
2. Voucher starts as **Pending payment** and shows in your Owner dashboard.
3. Customer pays by mobile money (your number from `paymentInfo`).
4. You press **✔ Mark as paid** — the code becomes *Active*. Use **Copy** to send the ticket by SMS/WhatsApp.

Safety built in: max 10 unpaid vouchers per phone number, request rate limiting, unique codes (letters `I, L, O, Q` are excluded to avoid confusion), and the request list is never exposed publicly.

## 🌍 Put it online so customers can use it

The free/live preview in this chat is temporary. To run the app 24/7, deploy it to any Node.js host — free tiers work fine:

- **Render / Railway / Fly.io** → new web service, start command `node server.js`, port `3000`
- **Replit / Glitch** → upload the folder, run `node server.js`
- A small **VPS** (or even your MikroTik router with containers, if you have one)

All these platforms give you HTTPS so the Owner PIN travels encrypted.

## 📁 Files

```
server.js          → the whole backend (no dependencies, pure Node.js)
public/index.html  → shop + owner dashboard (one file)
config.json        → your shop settings
data/requests.json → all customer requests (auto-created)
```

## 💡 Possible next steps

- WhatsApp button so customers receive their ticket by message
- Auto-create users on your **MikroTik hotspot** the moment you mark paid
- MVola / Orange Money payment API integration
- French / Malagasy language switch
